import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rice',
  templateUrl: './rice.component.html',
  styleUrls: ['./rice.component.css']
})
export class RiceComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
