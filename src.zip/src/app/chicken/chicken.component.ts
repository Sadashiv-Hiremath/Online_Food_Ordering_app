import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-chicken',
  templateUrl: './chicken.component.html',
  styleUrls: ['./chicken.component.css']
})
export class ChickenComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
