import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-rotis',
  templateUrl: './rotis.component.html',
  styleUrls: ['./rotis.component.css']
})
export class RotisComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
